| Kill | Recovery |
|---|---|
| standard treated as final truth | rerun axiomogenesis |
| residual erased | restore residual ledger |
| dissent suppressed | restore noospheric membrane |
| phenomenal proof claimed | downgrade to residual |
| live bio or BCI procedure added | remove and re-audit |
