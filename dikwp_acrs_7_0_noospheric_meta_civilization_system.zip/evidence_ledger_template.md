| Claim | Source | Support | Not Supported | Reliability | Kill |
|---|---|---|---|---|---|
