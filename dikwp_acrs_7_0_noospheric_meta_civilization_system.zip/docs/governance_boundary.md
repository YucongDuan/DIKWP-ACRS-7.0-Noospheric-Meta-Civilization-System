# Governance Boundary

The package is dry digital-twin research only. It excludes live BCI, wet-lab steps, organoid procedures, external actuation and host-level capabilities. Phenomenal and collective phenomenal claims remain blocked.
