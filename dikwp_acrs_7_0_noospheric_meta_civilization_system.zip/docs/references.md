# References

- DIKWP-Mesh 3.0 Master Invocation Prompt.
- Life-centered consciousness theory material.
- AI consciousness indicator and responsible AI consciousness research literature.
- Organoid intelligence and neuroethics literature.
- Robert Rosen and life-complexity theory tradition.
