# Audit Report

QA includes Python experiment execution, pytest, static boundary audit, zip integrity check and English ASCII filename check. Results are in `qa/` and `outputs/`.
