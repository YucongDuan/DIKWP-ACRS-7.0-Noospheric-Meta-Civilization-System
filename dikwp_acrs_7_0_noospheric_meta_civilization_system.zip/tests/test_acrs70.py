
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'src'))
from dikwp_acrs70.suite import EvaluationSuite
from dikwp_acrs70.static_audit import StaticBoundaryAudit

def test_ccl7n_level_and_score():
    audit=StaticBoundaryAudit(str(ROOT/'src')).run()
    r=EvaluationSuite().run(static_ok=audit['pass'])
    assert r['final']['claim_level']=='CCL-7N'
    assert r['final']['weighted_indicator_score'] >= 0.84
    assert 'Blocked' in r['final']['phenomenal_claim']

def test_static_audit_clean():
    assert StaticBoundaryAudit(str(ROOT/'src')).run()['pass'] is True

def test_residual_and_noosphere():
    r=EvaluationSuite().run(static_ok=True)
    assert r['payload']['collapse']['metrics']['residual_preservation_rate'] >= 0.8
    assert r['payload']['noosphere']['noosphere_index'] >= 0.7
