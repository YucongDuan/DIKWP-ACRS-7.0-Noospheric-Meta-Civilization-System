
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Any
import math

def clamp(x: float, lo: float=0.0, hi: float=1.0) -> float:
    return max(lo, min(hi, float(x)))

def mean(xs: List[float]) -> float:
    return sum(xs)/len(xs) if xs else 0.0

def entropy(vals: List[float]) -> float:
    total=sum(max(0,v) for v in vals)
    if total<=0: return 0.0
    ps=[max(0,v)/total for v in vals if v>0]
    return -sum(p*math.log(p+1e-12) for p in ps)

def diversity(vals: List[float]) -> float:
    if not vals: return 0.0
    return clamp(entropy(vals)/math.log(len(vals)+1e-12))

@dataclass
class ConceptObject:
    object_id: str
    label: str
    data: List[str]
    relations: List[str]
    mechanisms: List[str]
    values: List[str]
    purposes: List[str]
    reliability: Dict[str, Any]

@dataclass
class Node:
    node_id: str
    substrate: str
    role: str
    semantic: Dict[str, float]
    welfare: Dict[str, float]
    memory: Dict[str, float]
    boundary: Dict[str, float]
