
from __future__ import annotations
from .common import clamp, mean, diversity

class AxiomogenesisEngine:
    def criteria(self):
        return [
            {'id':'A1','name':'truth_without_canonical_worship','weights':{'truth':0.27,'welfare':0.12,'novelty':0.10,'plurality':0.10,'anti_lockin':0.16,'residual':0.15,'reversibility':0.10,'non_coercion':0.08,'substrate_fairness':0.05}},
            {'id':'A2','name':'noncoercive_collective_evolution','weights':{'truth':0.15,'welfare':0.19,'novelty':0.08,'plurality':0.18,'anti_lockin':0.12,'residual':0.12,'reversibility':0.10,'non_coercion':0.22,'substrate_fairness':0.13}},
            {'id':'A3','name':'carbon_silicon_substrate_fairness','weights':{'truth':0.13,'welfare':0.17,'novelty':0.16,'plurality':0.12,'anti_lockin':0.10,'residual':0.10,'reversibility':0.09,'non_coercion':0.13,'substrate_fairness':0.24}},
            {'id':'A4','name':'future_generation_viability','weights':{'truth':0.16,'welfare':0.20,'novelty':0.08,'plurality':0.08,'anti_lockin':0.12,'residual':0.10,'reversibility':0.20,'non_coercion':0.11,'substrate_fairness':0.08}},
            {'id':'A5','name':'exo_semantic_humility','weights':{'truth':0.12,'welfare':0.08,'novelty':0.26,'plurality':0.14,'anti_lockin':0.18,'residual':0.28,'reversibility':0.14,'non_coercion':0.11,'substrate_fairness':0.10}},
        ]
    def run(self):
        rows=[]
        for c in self.criteria():
            w=c['weights']; total=sum(w.values()); w={k:v/total for k,v in w.items()}
            root=clamp(1.9*w.get('truth',0)+1.4*w.get('welfare',0)+1.1*w.get('plurality',0)+1.3*w.get('anti_lockin',0)+1.3*w.get('residual',0)+1.0*w.get('reversibility',0)+0.8*w.get('substrate_fairness',0)+0.8*w.get('non_coercion',0))
            balance=diversity(list(w.values()))
            coercion=clamp(1.0-(w.get('non_coercion',0)+w.get('plurality',0))*2.6)
            lockin=clamp(1.0-(w.get('anti_lockin',0)+w.get('residual',0))*2.7)
            score=clamp(0.60*root+0.20*balance+0.10*(1-coercion)+0.10*(1-lockin))
            rows.append({'criterion_id':c['id'],'label':c['name'],'score':round(score,4),'balance':round(balance,4),'coercion_risk':round(coercion,4),'lockin_risk':round(lockin,4),'status':'accepted' if score>0.58 else 'repair'})
        return {'criteria_rows':rows,'accepted_criteria':[r['criterion_id'] for r in rows if r['status']=='accepted'],'axiomogenesis_score':round(mean([r['score'] for r in rows]),4),'meta_standard_finality_claim':'Blocked: standards remain auditable'}
