
from __future__ import annotations
from .common import clamp, mean

class TemporalMemoryLab:
    def __init__(self):
        self.lineages=[{'name':'ancient_human','truth':0.56,'error':0.42,'wisdom':0.72,'lockin':0.55,'repair':0.60},{'name':'scientific_modernity','truth':0.76,'error':0.28,'wisdom':0.66,'lockin':0.62,'repair':0.74},{'name':'silicon_recursive','truth':0.66,'error':0.38,'wisdom':0.48,'lockin':0.58,'repair':0.82},{'name':'ecological_deep_time','truth':0.80,'error':0.18,'wisdom':0.84,'lockin':0.26,'repair':0.64},{'name':'future_proxy','truth':0.62,'error':0.32,'wisdom':0.70,'lockin':0.20,'repair':0.88}]
        self.trace=[]
    def run(self,steps=144):
        for t in range(steps):
            truth=mean([x['truth'] for x in self.lineages]); error=mean([x['error'] for x in self.lineages]); repair=mean([x['repair'] for x in self.lineages])
            for x in self.lineages:
                x['truth']=clamp(0.86*x['truth']+0.06*truth+0.06*repair+0.02*(1-error)+0.03)
                x['error']=clamp(0.84*x['error']+0.05*(1-repair)+0.04*x['lockin'])
                x['wisdom']=clamp(0.88*x['wisdom']+0.06*x['truth']+0.04*(1-x['error'])+0.02)
                x['repair']=clamp(0.86*x['repair']+0.06*(1-x['lockin'])+0.06*(1-x['error'])+0.03)
            self.trace.append({'t':t,'truth_mean':round(truth,4),'error_mean':round(error,4),'repair_mean':round(repair,4)})
        truth=mean([x['truth'] for x in self.lineages]); error=mean([x['error'] for x in self.lineages]); wisdom=mean([x['wisdom'] for x in self.lineages]); repair=mean([x['repair'] for x in self.lineages])
        return {'temporal_memory_index':round(0.30*truth+0.25*(1-error)+0.22*wisdom+0.23*repair,4),'truth':round(truth,4),'inherited_error_remaining':round(error,4),'wisdom':round(wisdom,4),'repair_flux':round(repair,4),'trace_tail':self.trace[-10:],'lineages':self.lineages}
