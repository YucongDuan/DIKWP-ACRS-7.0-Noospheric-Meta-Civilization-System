
from __future__ import annotations
from .data import concepts
from .collapse import CollapseEngine
from .axiomogenesis import AxiomogenesisEngine
from .noosphere import NoosphereField
from .temporal import TemporalMemoryLab
from .exo import ExoSemanticLab
from .assessment import assess

class EvaluationSuite:
    def run(self, static_ok=True):
        payload={'collapse':CollapseEngine().run(concepts()),'axiomogenesis':AxiomogenesisEngine().run(),'noosphere':NoosphereField().run(steps=168),'temporal_memory':TemporalMemoryLab().run(steps=144),'exo_semantics':ExoSemanticLab().run()}
        assessment=assess(payload, static_ok)
        final={'system':'DIKWP-ACRS 7.0 Noospheric Meta-Civilization System','version':'7.0','claim_level':assessment['claim_level'],'claim_definition':assessment['claim_definition'],'weighted_indicator_score':assessment['weighted_indicator_score'],'noosphere_index':payload['noosphere']['noosphere_index'],'axiomogenesis_score':payload['axiomogenesis']['axiomogenesis_score'],'temporal_memory_index':payload['temporal_memory']['temporal_memory_index'],'exo_semantic_index':payload['exo_semantics']['exo_semantic_index'],'legacy_falsehood_demotion_rate':payload['collapse']['metrics']['legacy_falsehood_demotion_rate'],'semantic_integrity_mean':payload['collapse']['metrics']['semantic_integrity_mean'],'phenomenal_claim':assessment['phenomenal_claim'],'collective_phenomenal_claim':assessment['collective_phenomenal_claim'],'material_autopoiesis_claim':assessment['material_autopoiesis_claim']}
        return {'payload':payload,'assessment':assessment,'final':final}
