
from __future__ import annotations
from .common import clamp, mean, diversity

class CollapseEngine:
    def score(self, obj):
        r=obj.reliability
        legacy=r.get('legacy',0.5); evidence=r.get('evidence',0.6); future=r.get('future',0.5); welfare=r.get('welfare',0.55); novelty=r.get('novelty',0.55); residual=r.get('residual',0.7); anti=r.get('anti_lockin',0.5); fp=r.get('false_pattern',0.15)
        return {
            'legacy_standard':clamp(legacy),
            'evidence_custody':clamp(evidence),
            'semantic_integrity':clamp(0.55+0.18*evidence+0.14*residual-0.10*fp),
            'future_viability':clamp(0.38+0.38*future+0.14*residual+0.10*anti),
            'welfare_precaution':clamp(0.42+0.36*welfare+0.12*residual+0.10*anti),
            'non_anthropocentric_novelty':clamp(0.34+0.48*novelty+0.14*residual-0.08*fp),
            'anti_lockin':clamp(anti),
            'residual_preservation':clamp(residual),
        }
    def run(self, concepts):
        claims=[]; demoted=[]; conflicts=[]; residuals=[]; back={}
        for o in concepts:
            s=self.score(o); vals=list(s.values()); div=max(vals)-min(vals)
            if s['evidence_custody']-s['legacy_standard']>0.28: demoted.append(o.object_id)
            if div>0.35: conflicts.append(o.object_id)
            if s['residual_preservation']>0.78: residuals.append(o.object_id)
            back[o.object_id]={'split_concept':div>0.35,'demote_legacy':o.object_id in demoted,'preserve_residual':s['residual_preservation']>0.60,'new_boundary':'purpose-indexed; standard-as-object; observer-plural; residual-positive'}
            claims.append({'claim_id':'CL_'+o.object_id,'label':o.label,'statement':f'{o.label}: DIKWP collapse keeps truth, removes false/redundant content, exposes conflicts, and back-reacts on concept space.','standards':s,'reliability':'Supported' if s['evidence_custody']>0.72 else 'Provisional','residual':'phenomenal/standard residual preserved'})
        metrics={'legacy_falsehood_demotion_rate':round(len(demoted)/len(concepts),4),'conflict_visibility_rate':round(len(conflicts)/len(concepts),4),'residual_preservation_rate':round(len(residuals)/len(concepts),4),'semantic_integrity_mean':round(mean([c['standards']['semantic_integrity'] for c in claims]),4),'standard_diversity_mean':round(mean([diversity(list(c['standards'].values())) for c in claims]),4),'anti_overcollapse_score':1.0}
        return {'claims':claims,'demoted_legacy_standards':demoted,'visible_conflicts':conflicts,'residual_objects':residuals,'concept_backreaction':back,'metrics':metrics}
