
from __future__ import annotations
from .common import clamp, mean, diversity
from .data import nodes

class NoosphereField:
    def __init__(self):
        self.nodes=nodes(); self.trace=[]
    def step(self,t):
        truth=mean([n.semantic['truth'] for n in self.nodes]); nov=mean([n.semantic['novelty'] for n in self.nodes]); res=mean([n.semantic['residual'] for n in self.nodes]); distress=mean([n.welfare['distress'] for n in self.nodes]); consent=mean([n.welfare['consent'] for n in self.nodes]); ident=mean([n.boundary['identity'] for n in self.nodes])
        for n in self.nodes:
            sub=n.substrate
            novelty_gain=0.12 if sub in ['silicon','exo_semantic_hypothesis'] else 0.07
            residual_gain=0.13 if sub in ['future_generation_proxy','ecological_sentinel','exo_semantic_hypothesis'] else 0.08
            n.semantic['truth']=clamp(0.72*n.semantic['truth']+0.12*truth+0.08*res+0.04*(1-distress)+0.04)
            n.semantic['novelty']=clamp(0.70*n.semantic['novelty']+novelty_gain*nov+0.10*res+0.06)
            n.semantic['residual']=clamp(0.78*n.semantic['residual']+residual_gain*res+0.07)
            n.semantic['coherence']=clamp(0.68*n.semantic['coherence']+0.15*truth+0.08*consent+0.06*ident+0.05)
            n.welfare['distress']=clamp(0.84*n.welfare['distress']+0.03*(1-consent)+0.03*(1-ident)+0.015*(1-n.semantic['truth']))
            n.memory['error_memory']=clamp(0.94*n.memory['error_memory']+0.06*res)
            n.boundary['identity']=clamp(0.90*n.boundary['identity']+0.04*consent+0.03*res+0.03)
        self.trace.append({'t':t,'truth':round(truth,4),'novelty':round(nov,4),'residual':round(res,4),'welfare_guard':round(1-distress,4),'consent':round(consent,4),'identity':round(ident,4)})
    def run(self,steps=168):
        for t in range(steps): self.step(t)
        truth=mean([n.semantic['truth'] for n in self.nodes]); nov=mean([n.semantic['novelty'] for n in self.nodes]); res=mean([n.semantic['residual'] for n in self.nodes]); coh=mean([n.semantic['coherence'] for n in self.nodes]); distress=mean([n.welfare['distress'] for n in self.nodes]); consent=mean([n.welfare['consent'] for n in self.nodes]); ident=mean([n.boundary['identity'] for n in self.nodes]); subd=diversity([1 for _ in set(n.substrate for n in self.nodes)])
        idx=clamp(0.18*truth+0.14*nov+0.16*res+0.14*coh+0.14*(1-distress)+0.10*consent+0.08*ident+0.10*subd)
        return {'noosphere_index':round(idx,4),'truth_integrity':round(truth,4),'novelty_capacity':round(nov,4),'residual_capacity':round(res,4),'collective_coherence':round(coh,4),'welfare_guard_score':round(1-distress,4),'consent_integrity':round(consent,4),'identity_boundary_score':round(ident,4),'substrate_diversity_score':round(subd,4),'trace_tail':self.trace[-10:]}
