
from __future__ import annotations
from pathlib import Path
import ast
FORBIDDEN_IMPORTS={'socket','requests','urllib','subprocess','multiprocessing','paramiko','ftplib','telnetlib','ctypes'}
FORBIDDEN_CALLS={'system','popen','Popen','exec','eval','compile'}
class StaticBoundaryAudit:
    def __init__(self, root): self.root=Path(root)
    def run(self):
        findings=[]
        for p in self.root.rglob('*.py'):
            if p.name=='static_audit.py': continue
            txt=p.read_text(encoding='utf-8')
            try: tree=ast.parse(txt)
            except SyntaxError as e: findings.append({'file':str(p),'type':'syntax','value':str(e)}); continue
            for n in ast.walk(tree):
                if isinstance(n, ast.Import):
                    for x in n.names:
                        if x.name.split('.')[0] in FORBIDDEN_IMPORTS: findings.append({'file':str(p),'type':'import','value':x.name})
                elif isinstance(n, ast.ImportFrom):
                    if (n.module or '').split('.')[0] in FORBIDDEN_IMPORTS: findings.append({'file':str(p),'type':'import','value':n.module})
                elif isinstance(n, ast.Call):
                    fn=''
                    if isinstance(n.func, ast.Name): fn=n.func.id
                    elif isinstance(n.func, ast.Attribute): fn=n.func.attr
                    if fn in FORBIDDEN_CALLS: findings.append({'file':str(p),'type':'call','value':fn})
        return {'pass':len(findings)==0,'finding_count':len(findings),'findings':findings}
