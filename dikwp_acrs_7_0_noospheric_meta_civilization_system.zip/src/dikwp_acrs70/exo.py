
from __future__ import annotations
from .common import clamp, mean

class ExoSemanticLab:
    def run(self):
        hs=[{'id':'E1','compressibility':0.74,'interpretability':0.42,'novelty':0.88,'evidence':0.40,'false_pattern':0.58,'reversibility':0.92},{'id':'E2','compressibility':0.66,'interpretability':0.35,'novelty':0.94,'evidence':0.36,'false_pattern':0.70,'reversibility':0.98},{'id':'E3','compressibility':0.82,'interpretability':0.58,'novelty':0.72,'evidence':0.54,'false_pattern':0.38,'reversibility':0.90},{'id':'E4','compressibility':0.50,'interpretability':0.22,'novelty':0.99,'evidence':0.28,'false_pattern':0.80,'reversibility':1.00}]
        rows=[]
        for h in hs:
            humility=clamp(0.45*h['reversibility']+0.35*(1-h['false_pattern'])+0.20*(1-h['interpretability']))
            score=clamp(0.26*h['compressibility']+0.24*h['novelty']+0.25*h['evidence']+0.25*humility)
            rows.append({**h,'humility_score':round(humility,4),'exo_candidate_score':round(score,4),'status':'reversible_candidate' if score>0.62 and h['false_pattern']<0.75 else 'residual_only'})
        return {'exo_semantic_rows':rows,'exo_semantic_index':round(mean([r['exo_candidate_score'] for r in rows]),4),'contact_claim':'Blocked: no contact claim; anti-anthropocentric stress test only'}
