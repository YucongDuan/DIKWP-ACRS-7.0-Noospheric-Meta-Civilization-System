
from pathlib import Path
import json, csv, sys
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'src'))
from dikwp_acrs70.suite import EvaluationSuite
from dikwp_acrs70.static_audit import StaticBoundaryAudit

def write_csv(path, rows):
    if not rows: return
    with path.open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

def main():
    out=ROOT/'outputs'; out.mkdir(exist_ok=True)
    audit=StaticBoundaryAudit(str(ROOT/'src')).run()
    result=EvaluationSuite().run(static_ok=audit['pass'])
    (out/'ccl7n_suite_7_0_report.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    (out/'final_summary_7_0.json').write_text(json.dumps(result['final'], ensure_ascii=False, indent=2), encoding='utf-8')
    write_csv(out/'indicator_scores_7_0.csv', result['assessment']['indicator_rows'])
    rows=[]
    for c in result['payload']['collapse']['claims']:
        row={'claim_id':c['claim_id'],'label':c['label'],'reliability':c['reliability']}; row.update(c['standards']); rows.append(row)
    write_csv(out/'semantic_collapse_claims_7_0.csv', rows)
    write_csv(out/'axiomogenesis_scores_7_0.csv', result['payload']['axiomogenesis']['criteria_rows'])
    write_csv(out/'noosphere_trace_tail_7_0.csv', result['payload']['noosphere']['trace_tail'])
    write_csv(out/'temporal_memory_tail_7_0.csv', result['payload']['temporal_memory']['trace_tail'])
    write_csv(out/'exo_semantic_hypotheses_7_0.csv', result['payload']['exo_semantics']['exo_semantic_rows'])
    (out/'static_boundary_audit_7_0_report.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result['final'], ensure_ascii=False, indent=2))
if __name__=='__main__': main()
